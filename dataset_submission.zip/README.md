# Multimodal Emotion Recognition Dataset Sample

## Overview
This is a **representative sample** of the full dataset used to train the emotion recognition model.
The full dataset contains 10253 preprocessed audio samples across multiple emotion classes.

## Dataset Structure
- **Format**: `.npz` (NumPy compressed arrays)
- **Content**: Preprocessed audio features (MFCCs, spectral features, etc.)
- **Emotions**: Happiness, Sadness, Anger (3-class classification)

## Sample Statistics
- **Total samples in this archive**: 15
- **Full dataset size**: 353.7 MB
- **Full dataset samples**: 10253

### Samples per Emotion Class:
- **Happiness**: 5 samples (full dataset: 1463)
- **Sadness**: 5 samples (full dataset: 1463)
- **Anger**: 5 samples (full dataset: 1463)


## Source Datasets

### 1. IEMOCAP (Interactive Emotional Dyadic Motion Capture)
- **Source**: USC SAIL Lab
- **Content**: Acted emotional speech from scripted and improvised scenarios
- **Speakers**: 10 actors (5 male, 5 female)
- **Sessions**: Multiple improvisation and scripted scenarios
- **Emotions**: Happiness, Sadness, Anger, Neutral, Frustrated, Excited, etc.

### 2. RAVDESS (Ryerson Audio-Visual Database of Emotional Speech and Song)
- **Source**: Ryerson University
- **Content**: Professional actors speaking emotional sentences
- **Speakers**: 24 actors (12 male, 12 female)
- **Emotions**: Calm, Happy, Sad, Angry, Fearful, Surprise, Disgust
- **Format**: Emotional speech with controlled intensity

## File Naming Convention

### IEMOCAP Files:
`iemocap_Ses[Session][Gender]_[Type][Num]_[Speaker][ID].npz`
- Example: `iemocap_Ses05F_impro03_F008.npz`
  - Session 05, Female speaker, Improvisation 03, Speaker F, Utterance 008

### RAVDESS Files:
`ravdess_[Modality]-[Channel]-[Emotion]-[Intensity]-[Statement]-[Repetition]-[Actor].npz`
- Example: `ravdess_03-01-03-01-01-01-01.npz`
  - Code 03 = Speech, Code 01 = Audio-only, Code 03 = Happy, etc.

## Preprocessing Pipeline

Each `.npz` file contains:
1. **Audio features** extracted using:
   - MFCC (Mel-Frequency Cepstral Coefficients)
   - Spectral features (centroid, bandwidth, rolloff)
   - Prosodic features (pitch, energy, zero-crossing rate)

2. **Text transcriptions** (for multimodal fusion)

3. **Metadata**:
   - Emotion label (0=Happiness, 1=Sadness, 2=Anger)
   - Dataset source (IEMOCAP, RAVDESS, etc.)
   - Speaker ID, session info

## Model Training

The model was trained using:
- **Architecture**: DistilRoBERTa-base fine-tuned for emotion classification
- **Training samples**: ~10253 preprocessed samples
- **Validation split**: 20%
- **Test accuracy**: 87.72%
- **F1-Score**: 87.60%

## Usage

To load a sample:
```python
import numpy as np

# Load sample
data = np.load('iemocap_Ses05F_impro03_F008.npz', allow_pickle=True)

# Access features
audio_features = data['audio_features']
text = data['text']
emotion_label = data['emotion']  # 0=Happiness, 1=Sadness, 2=Anger
```

## Academic Reference

This dataset was used for the Honors Project:
**"Multimodal Emotion Recognition System Using Hybrid Deep Learning"**

For access to the full dataset, please refer to:
- IEMOCAP: https://sail.usc.edu/iemocap/
- RAVDESS: https://zenodo.org/record/1188976

---

**Note**: Due to submission size constraints (10MB limit), this archive contains only
a representative sample. The full preprocessed dataset is available upon request.
